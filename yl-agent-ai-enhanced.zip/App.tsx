
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { 
  Search, MapPin, Globe, Mail, Phone, RefreshCw, Sparkles, Send, Copy, X, 
  Settings, Bot, Zap, Rocket, CheckCircle2, Crown, Plus, CheckSquare, Square, 
  Compass, Eye, Filter, Target, Twitter, PlayCircle, MessageCircle, ExternalLink, 
  Languages, Activity, Globe2, MoreVertical, FileText, Key, Server, Database, HelpCircle, 
  ChevronDown, BookOpen, UserCheck, Tag, Linkedin, Facebook, Instagram, Trash2,
  BarChart3, ShieldCheck, LayoutDashboard, Share2, Music2
} from 'lucide-react';
import { Lead, SearchParams } from './types';
import { 
  searchBusinessesOnMap, 
  enrichLeadWithSearch, 
apiStats,
  testApiKey,
  testFetchProxy,
  sleep,
  requestAbortSearch
} from './services/geminiService';

const ADMIN_SECRET = "Qq2492425226"; 

const PLAN_LABELS: Record<string, string> = {
    "TRL": "7天版",
    "MON": "30天版",
    "HALF": "180天版",
    "YEAR": "365天版",
    "PERM": "永久版",
    "AGENT": "代理商版",
    "ADMIN": "👑 创始人系统"
};

const PLAN_DAYS: Record<string, number> = {
  TRL: 7,
  MON: 30,
  HALF: 180,
  YEAR: 365,
  PERM: 0,
  AGENT: 365,
  ADMIN: 0,
};

const calcExpiresAt = (plan: string, activatedAt: number) => {
  const days = PLAN_DAYS[plan] ?? 0;
  if (!days) return null;
  return activatedAt + days * 24 * 60 * 60 * 1000;
};

const calcRemainingDays = (expiresAt?: number | null) => {
  if (!expiresAt) return null;
  const ms = expiresAt - Date.now();
  return Math.max(0, Math.ceil(ms / (24 * 60 * 60 * 1000)));
};


const ensureHttp = (url?: string) => {
  if (!url || url === "" || url === "null") return '';
  if (url.startsWith('http') || url.startsWith('mailto:') || url.startsWith('tel:') || url.startsWith('https://wa.me')) return url;
  return `https://${url}`;
};


const buildWhatsAppLink = (val?: string) => {
  if (!val) return '';
  const v = String(val).trim();
  if (!v) return '';
  if (/wa\.me|whatsapp\.com/i.test(v)) return ensureHttp(v);
  // 纯号码：拼 wa.me
  const digits = v.replace(/[^\d]/g, '');
  if (digits.length >= 6) return `https://wa.me/${digits}`;
  return '';
};

const App: React.FC = () => {
  const [license, setLicense] = useState<any>(null);
  const [licenseInput, setLicenseInput] = useState('');
  // 客户库（可长期保存）
  const [leads, setLeads] = useState<Lead[]>([]);
  // 雷达结果（每次搜索生成，可一键导入客户库）
  const [radarLeads, setRadarLeads] = useState<Lead[]>([]);
  const [activeTab, setActiveTab] = useState<'radar' | 'library'>('radar');
  const [loading, setLoading] = useState(false);
  const [searchStatus, setSearchStatus] = useState('');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [params, setParams] = useState<SearchParams>({ query: '', location: '', limit: 10, probeWebsite: true, webBoost: true, targets: ['批发商/分销商','供应商/工厂','采购商/进口商','零售店/店主','连锁品牌/门店'] });
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  
  const [showSettings, setShowSettings] = useState(false);
  const [showNetworkModal, setShowNetworkModal] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  
  const [isTestingApi, setIsTestingApi] = useState(false);
  const [isTestingFetch, setIsTestingFetch] = useState(false);
  const [generatedKeys, setGeneratedKeys] = useState<any[]>([]);
  const [toasts, setToasts] = useState<any[]>([]);
  const [currentFilter, setCurrentFilter] = useState('全部');

  const [settings, setSettings] = useState({
    userName: localStorage.getItem('yl_user_name') || '外贸专家',
    userCompany: localStorage.getItem('yl_user_company') || '我的外贸公司'
  });

  const [networkConfig, setNetworkConfig] = useState(() => {
    const legacy = localStorage.getItem('yl_api_proxy') || '';
    const geminiProxyUrl = localStorage.getItem('yl_gemini_proxy') || ((legacy && !legacy.includes('{url}')) ? legacy : '');
    const fetchProxyUrl = localStorage.getItem('yl_fetch_proxy') || ((legacy && legacy.includes('{url}')) ? legacy : '');
    return {
      apiKey: localStorage.getItem('yl_api_key') || '',
      geminiProxyUrl,
      fetchProxyUrl,
    };
  });

  useEffect(() => {
    const sl = localStorage.getItem('yl_leads_v13'); if(sl) try{setLeads(JSON.parse(sl))}catch(e){}
    const sli = localStorage.getItem('yl_license_v13'); if(sli) try{setLicense(JSON.parse(sli))}catch(e){}
    const sgk = localStorage.getItem('yl_admin_keys_v13'); if(sgk) try{setGeneratedKeys(JSON.parse(sgk))}catch(e){}
  }, []);

  useEffect(() => { localStorage.setItem('yl_leads_v13', JSON.stringify(leads)); }, [leads]);


useEffect(() => {
  if (!license || license.isAdmin) return;

  const activatedAt = license.activatedAt || Date.now();
  const expiresAt = license.plan === 'PERM' ? null : (license.expiresAt ?? calcExpiresAt(license.plan, activatedAt));

  if (expiresAt && Date.now() > expiresAt) {
    localStorage.removeItem('yl_license_v13');
    setLicense(null);
    addToast("卡密已过期，请联系管理员续费", "error");
    return;
  }

  // 补全缺失字段（兼容旧数据）
  if ((license.activatedAt !== activatedAt) || (license.expiresAt !== expiresAt)) {
    const patched = { ...license, activatedAt, expiresAt };
    setLicense(patched);
    localStorage.setItem('yl_license_v13', JSON.stringify(patched));
  }
}, [license, addToast]);

  const copyToClipboard = (text: string, label: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    addToast(`${label} 已复制`, "success");
  };

  const handleLogin = (e: React.FormEvent) => {
  e.preventDefault();
  const input = licenseInput.trim();
  if (!input) return;

  if (input === ADMIN_SECRET) {
    const lic = { isAdmin: true, plan: "ADMIN", key: input, activatedAt: Date.now(), expiresAt: null };
    setLicense(lic);
    localStorage.setItem('yl_license_v13', JSON.stringify(lic));
    addToast(`欢迎进入 ${PLAN_LABELS.ADMIN} `, "success");
    return;
  }

  if (input.length <= 5) return addToast("卡密无效或已过期", "error");

  const prefix = input.split('-')[0].toUpperCase();
  const allowed = new Set(["TRL", "MON", "HALF", "YEAR", "PERM", "AGENT"]);
  const plan = allowed.has(prefix) ? prefix : (input.includes("PERM") ? "PERM" : input.includes("YEAR") ? "YEAR" : "TRL");

  // 激活时间：同一张卡密重复登录时，保留第一次激活时间（避免反复延长）
  const prevRaw = localStorage.getItem('yl_license_v13');
  let activatedAt = Date.now();
  try {
    const prev = prevRaw ? JSON.parse(prevRaw) : null;
    if (prev?.key === input && prev?.activatedAt) activatedAt = prev.activatedAt;
  } catch {}

  const expiresAt = plan === "PERM" ? null : calcExpiresAt(plan, activatedAt);

  // 过期拦截
  if (expiresAt && Date.now() > expiresAt) {
    localStorage.removeItem('yl_license_v13');
    setLicense(null);
    return addToast("卡密已过期，请联系管理员续费", "error");
  }

  const lic = { isAdmin: false, plan, key: input, activatedAt, expiresAt };
  setLicense(lic);
  localStorage.setItem('yl_license_v13', JSON.stringify(lic));
  addToast(`验证成功，欢迎进入 ${PLAN_LABELS[plan]} 系统`, "success");
};

  
const handleSearch = async (e: React.FormEvent) => {
  e.preventDefault();
  if (!params.query || !params.location) return;
  setLoading(true);
  try {
    const res = await searchBusinessesOnMap(
      params.query,
      params.location,
      params.limit,
      setSearchStatus,
      params.targets as any,
      { probeWebsite: params.probeWebsite, webBoost: params.webBoost }
    );
    setRadarLeads(res.leads);
    setActiveTab('radar');
    setSelectedIds(new Set());
    setSelectedLead(null);
    addToast(`本次雷达命中 ${res.leads.length} 个目标（可勾选后一键导入客户库）`, "success");
  } catch (err: any) {
    addToast(err?.message || "搜索失败，请检查网络/Key/中转设置", "error");
  } finally {
    setLoading(false);
    setSearchStatus('');
  }
};

const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSelectAll = () => {
    const list = displayedLeads;
    if (selectedIds.size === list.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(list.map(l => l.id)));
  };

  const normalizeBusinessName = (name: string): string => {
    if (!name) return "";
    return name.toLowerCase()
      .replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "")
      .replace(/\s+/g, "")
      .replace(/(inc|ltd|limited|corp|company|co|llc|gmbh|sa|pvt|pty|intl|group)$/g, "");
  };

  const isLeadDuplicateLocal = (newLead: Lead, existing: Lead[]) => {
    const normName = normalizeBusinessName(newLead.name || "");
    const normAddr = (newLead.address || "").toLowerCase().replace(/\s+/g, "").substring(0, 15);
    return existing.some(l => {
      if (l.id === newLead.id) return true;
      const exName = normalizeBusinessName(l.name);
      const exAddr = l.address.toLowerCase().replace(/\s+/g, "").substring(0, 15);
      if (normName === exName && normAddr === exAddr) return true;
      if (newLead.website && l.website && newLead.website.replace(/https?:\/\//, "") === l.website.replace(/https?:\/\//, "")) return true;
      return false;
    });
  };

  const handleImportToLibrary = () => {
    if (activeTab !== 'radar') return;
    const base = radarLeads;
    const picked = selectedIds.size > 0 ? base.filter(l => selectedIds.has(l.id)) : base;
    if (picked.length === 0) return addToast('请先勾选要导入的雷达结果', 'info');

    let imported = 0;
    setLeads(prev => {
      const next = [...prev];
      picked.forEach(l => {
        if (!isLeadDuplicateLocal(l, next)) {
          next.unshift({ ...l });
          imported += 1;
        }
      });
      return next;
    });
    addToast(`已导入客户库：${imported} 条（重复已自动跳过）`, imported > 0 ? 'success' : 'info');
  };

  const handleDeleteSelected = () => {
    if (selectedIds.size === 0) return addToast('请先勾选目标', 'info');
    const del = Array.from(selectedIds);
    if (!confirm(`确定删除所选 ${del.length} 条吗？此操作不可撤销。`)) return;
    if (activeTab === 'radar') setRadarLeads(prev => prev.filter(l => !selectedIds.has(l.id)));
    else setLeads(prev => prev.filter(l => !selectedIds.has(l.id)));
    setSelectedIds(new Set());
    addToast('已删除所选数据', 'success');
  };

  const handleClearCurrentTab = () => {
    if (activeTab === 'radar') {
      if (!confirm('确定清空本次雷达结果吗？')) return;
      setRadarLeads([]);
      setSelectedIds(new Set());
      setSelectedLead(null);
      addToast('雷达结果已清空', 'success');
      return;
    }
    if (!confirm('确定清空客户库中所有数据吗？此操作不可撤销。')) return;
    setLeads([]);
    setSelectedIds(new Set());
    setSelectedLead(null);
    addToast('客户库已清空', 'success');
  };

  const handleBatchEnrichIds = async (targetIds: string[]) => {
    if (targetIds.length === 0) return addToast("当前列表无可探测目标", "info");
    const isRadar = activeTab === 'radar';
    const list = isRadar ? radarLeads : leads;
    const setList = isRadar ? setRadarLeads : setLeads;

    addToast(`开始批量 AI 深度探测 ${targetIds.length} 个目标...`, "info");

    for (const id of targetIds) {
      const lead = list.find(l => l.id === id);
      if (lead && lead.enrichmentStatus !== 'completed') {
        try {
          setList(prev => prev.map(l => l.id === id ? { ...l, enrichmentStatus: 'loading' } : l));
          const enriched = await enrichLeadWithSearch(lead);
          setList(prev => prev.map(l => l.id === id ? { ...l, ...enriched } : l));
          await sleep(1500);
        } catch (e) {}
      }
    }
    addToast("批量 AI 深度探测任务已完成", "success");
  };

  const handleBatchEnrich = async () => {
    if (selectedIds.size === 0) return addToast("请先在列表中勾选目标", "info");
    return handleBatchEnrichIds(Array.from(selectedIds));
  };

  const handleEnrichAllVisible = async () => {
    if (displayedLeads.length === 0) return addToast("当前列表为空", "info");
    if (!confirm(`确定对当前列表 ${displayedLeads.length} 条执行深度探测吗？这会消耗 API 配额。`)) return;
    const ids = displayedLeads.map(l => l.id);
    setSelectedIds(new Set(ids));
    return handleBatchEnrichIds(ids);
  };

  const handleIndividualEnrich = async (lead: Lead) => {
    if (lead.enrichmentStatus === 'loading') return;
    const isRadar = activeTab === 'radar';
    const setList = isRadar ? setRadarLeads : setLeads;
    setList(prev => prev.map(l => l.id === lead.id ? { ...l, enrichmentStatus: 'loading' } : l));
    try {
        const enriched = await enrichLeadWithSearch(lead);
        setList(prev => prev.map(l => l.id === lead.id ? { ...l, ...enriched } : l));
        addToast("情报获取成功", "success");
    } catch (err: any) {
        setList(prev => prev.map(l => l.id === lead.id ? { ...l, enrichmentStatus: 'failed' } : l));
        addToast(err.message, "error");
    }
  };

  const handleExport = () => {
    const sourceList = selectedIds.size > 0
      ? (activeTab === 'radar' ? radarLeads : leads).filter(l => selectedIds.has(l.id))
      : displayedLeads;

    if (sourceList.length === 0) return addToast(activeTab === 'radar' ? '雷达结果为空' : '客户库无数据', 'info');

    const verifiedEmail = (l: Lead) => (l.email && l.evidence?.email?.sourceUrl) ? l.email : '';
    const verifiedPhone = (l: Lead) => (l.phone && l.evidence?.phone?.sourceUrl) ? l.phone : '';
    const verifiedWebsite = (l: Lead) => (l.website && l.evidence?.website?.sourceUrl) ? l.website : '';

    const exportable = sourceList
      .map(l => ({ ...l, email: verifiedEmail(l), phone: verifiedPhone(l), website: verifiedWebsite(l) }))
      .filter(l => !!l.email || !!l.phone);

    if (exportable.length === 0) {
      return addToast('为保证信息属实：没有可导出项（需至少有“电话/邮箱”的证据）', 'info');
    }

    const headers = '公司名,国家/地区,线索类型,邮箱,电话,官网,评分,评论数,AI评级,发掘状态,中文分析备注\n';
    const csvContent = exportable.map(l => (
      `"${l.name}","${l.country || ''}","${l.leadType || ''}","${l.email || ''}","${l.phone || ''}","${l.website || ''}","${(l.rating ?? '')}","${(l.userRatingCount ?? '')}","${l.grade || ''}","${l.enrichmentStatus === 'completed' ? '深度探测' : l.enrichmentStatus === 'probed' ? '网页抓取' : '基础'}","${(l.aiRemarkTranslated || l.basicIntro || '').replace(/"/g, '""')}"`
    )).join('\n');
    const blob = new Blob(["\uFEFF" + headers + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${activeTab === 'radar' ? 'YL雷达结果' : 'YL客户库'}_${new Date().getTime()}.csv`;
    link.click();
  };

  const filteredLeads = useMemo(() => {
    if (currentFilter === '全部') return leads;
    return leads.filter(l => l.grade === currentFilter);
  }, [leads, currentFilter]);

  const displayedLeads = useMemo(() => {
    return activeTab === 'radar' ? radarLeads : filteredLeads;
  }, [activeTab, radarLeads, filteredLeads]);

  if (!license) {
    return (
        <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
            <div className="bg-white p-10 rounded-3xl shadow-[0_0_50px_rgba(37,99,235,0.2)] w-full max-w-sm text-center animate-fadeIn border border-slate-100">
                <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-200">
                    <Bot className="w-8 h-8 text-white"/>
                </div>
                <h1 className="text-2xl font-black text-slate-900 mb-2 uppercase tracking-tighter italic">YL AGENT AI</h1>
                <p className="text-slate-400 text-[10px] mb-8 font-bold tracking-widest uppercase">全自动化外贸获客情报系统</p>
                <form onSubmit={handleLogin} className="space-y-4 text-left">
                    <div className="space-y-1">
                        <label className="text-[9px] font-black text-slate-400 uppercase ml-1">系统卡密</label>
                        <input type="password" value={licenseInput} onChange={e => setLicenseInput(e.target.value)} className="w-full px-5 py-3.5 bg-slate-50 rounded-2xl outline-none border-2 border-transparent focus:border-blue-500 transition-all font-bold tracking-widest text-center" placeholder="请输入 24 位激活卡密" />
                    </div>
                    <button type="submit" className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black shadow-lg hover:bg-blue-700 active:scale-95 transition-all uppercase tracking-widest text-xs">进入智能探测舱</button>
                </form>
                <div className="mt-10 pt-6 border-t border-slate-50 flex items-center justify-between opacity-50">
                    <span className="text-[8px] font-black text-slate-400 uppercase">技术支持: Yaozr888888</span>
                    <Crown className="w-3 h-3 text-yellow-500"/>
                </div>
            </div>
        </div>
    );
  }

  return (
    <div className="h-screen bg-slate-50 flex flex-col overflow-hidden text-[11px] select-none text-slate-700">
      <div className="fixed top-12 left-1/2 -translate-x-1/2 z-[3000] space-y-2 w-full max-w-[320px]">
        {toasts.map(t => (
          <div key={t.id} className={`px-5 py-3 rounded-2xl shadow-xl animate-slideDown flex items-center justify-center gap-3 font-black text-[10px] border-2 ${t.type === 'error' ? 'bg-red-50 text-red-600 border-red-100' : 'bg-white text-blue-600 border-blue-50'}`}>
            <div className={`w-2 h-2 rounded-full ${t.type === 'error' ? 'bg-red-500' : 'bg-blue-500'} animate-pulse`}></div>
            {t.message}
          </div>
        ))}
      </div>

      <header className="bg-white border-b px-5 h-12 flex items-center justify-between shrink-0 shadow-sm z-[100]">
          <div className="flex items-center gap-3">
              <div className="w-7 h-7 bg-slate-900 rounded-lg flex items-center justify-center shadow-lg">
                <Bot className="w-4 h-4 text-white"/>
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-black text-[12px] italic text-slate-900 uppercase">YL Agent AI</span>
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">全球获客探测系统</span>
              </div>
              <div className="ml-4 flex items-center gap-1.5">
  <span className={`px-2 py-0.5 rounded-full text-[8px] font-black text-white ${license.isAdmin ? 'bg-red-500' : 'bg-blue-600'} shadow-sm`}>{PLAN_LABELS[license.plan]}</span>
  {!license.isAdmin && license.plan !== 'PERM' && license.expiresAt && (
    <span className="px-2 py-0.5 rounded-full text-[8px] font-black bg-slate-900 text-white shadow-sm">
      剩余 {calcRemainingDays(license.expiresAt)} 天
    </span>
  )}
  {!license.isAdmin && license.plan === 'PERM' && (
    <span className="px-2 py-0.5 rounded-full text-[8px] font-black bg-slate-900 text-white shadow-sm">永久</span>
  )}
</div>
              
              <div className="ml-6 flex items-center gap-4 bg-slate-50 px-3 py-1 rounded-xl border border-slate-100">
                <div className="flex items-center gap-1.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-500"/>
                    <div className="flex flex-col">
                        <span className="text-[7px] font-black text-slate-400 uppercase">频率</span>
                        <span className="text-[10px] font-black text-slate-700">{apiStats.rpm} <span className="text-[8px] opacity-40">RPM</span></span>
                    </div>
                </div>
                <div className="w-px h-6 bg-slate-200"></div>
                <div className="flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5 text-blue-500"/>
                    <div className="flex flex-col">
                        <span className="text-[7px] font-black text-slate-400 uppercase">已调</span>
                        <span className="text-[10px] font-black text-slate-700">{apiStats.successCount} <span className="text-[8px] opacity-40">TIMES</span></span>
                    </div>
                </div>
              </div>
          </div>
          
          <div className="flex items-center gap-2">
              <button onClick={() => setShowHelpModal(true)} className="flex items-center gap-2 px-3 py-1.5 hover:bg-slate-50 rounded-xl text-slate-500 transition-all font-bold group" title="操作手册"><HelpCircle className="w-4 h-4 group-hover:text-blue-600"/><span className="text-[10px]">帮助中心</span></button>
              <button onClick={() => setShowNetworkModal(true)} className="flex items-center gap-2 px-3 py-1.5 hover:bg-slate-50 rounded-xl text-slate-500 transition-all font-bold group" title="网络与API"><Globe2 className="w-4 h-4 group-hover:text-blue-600"/><span className="text-[10px]">配额看板</span></button>
              <button onClick={() => setShowSettings(true)} className="flex items-center gap-2 px-3 py-1.5 hover:bg-slate-50 rounded-xl text-slate-500 transition-all font-bold group" title="业务设置"><Settings className="w-4 h-4 group-hover:text-blue-600"/><span className="text-[10px]">业务档案</span></button>
              {license.isAdmin && <button onClick={() => setShowAdminPanel(true)} className="p-2 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-all shadow-sm" title="创始人管理系统"><Crown className="w-4 h-4"/></button>}
          </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
          <aside className="w-60 bg-white border-r flex flex-col p-4 gap-5 shrink-0 overflow-y-auto custom-scrollbar">
              <form onSubmit={handleSearch} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">行业关键词</label>
                    <input required value={params.query} onChange={e => setParams({...params, query: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 rounded-xl border-2 border-transparent focus:border-blue-500/50 outline-none font-bold transition-all" placeholder="如: LED Lighting" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">目标国家/地区</label>
                    <input required value={params.location} onChange={e => setParams({...params, location: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 rounded-xl border-2 border-transparent focus:border-blue-500/50 outline-none font-bold transition-all" placeholder="如: Germany" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">扫描规模</label>
                    <select value={params.limit} onChange={e => setParams({ ...params, limit: parseInt(e.target.value) as any })} className="w-full px-4 py-2.5 bg-slate-50 rounded-xl outline-none cursor-pointer font-bold border-2 border-transparent">
                      <option value={10}>精选 10 个目标</option>
                      <option value={50}>批量 50 个目标</option>
                      <option value={100}>深度 100 个目标</option>
                      <option value={0}>无限地毯式扫描（一直搜）</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">搜索增强</label>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                      <label className="flex items-start gap-2 text-[10px] font-bold text-slate-600 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={params.probeWebsite ?? true}
                          onChange={(e) => setParams({ ...params, probeWebsite: e.target.checked })}
                          className="accent-blue-600 mt-0.5"
                        />
                        <span>
                          省API自动抓取邮箱/社媒（不消耗 Gemini；需在【配额看板】配置可用抓取代理 <span className="font-black">{'{url}'}</span>）
                        </span>
                      </label>
                      <label className="flex items-start gap-2 text-[10px] font-bold text-slate-600 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={params.webBoost ?? true}
                          onChange={(e) => setParams({ ...params, webBoost: e.target.checked })}
                          className="accent-blue-600 mt-0.5"
                        />
                        <span>强力补强：额外用 Google Search 挖掘采购商/进口商/目录/连锁/门店（少量消耗 API）</span>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">重点目标</label>
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                      {(['批发商/分销商','供应商/工厂','采购商/进口商','零售店/店主','连锁品牌/门店'] as const).map((t) => {
                        const checked = (params.targets || []).includes(t);
                        return (
                          <label key={t} className="flex items-center gap-2 text-[10px] font-bold text-slate-600 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={(e) => {
                                const next = new Set(params.targets || []);
                                if (e.target.checked) next.add(t);
                                else next.delete(t);
                                setParams({ ...params, targets: Array.from(next) });
                              }}
                              className="accent-blue-600"
                            />
                            {t}
                          </label>
                        );
                      })}
                      <p className="text-[9px] text-slate-400 font-bold leading-snug">提示：默认全选=全球全覆盖（批发/供应/采购/零售/连锁）。</p>
                    </div>
                  </div>
                  <button type="submit" disabled={loading} className="w-full py-3 bg-slate-900 text-white rounded-2xl font-black flex justify-center items-center gap-2 hover:bg-black transition-all active:scale-95 shadow-xl shadow-slate-200 uppercase tracking-widest">
                    {loading ? <RefreshCw className="w-4 h-4 animate-spin"/> : <Search className="w-4 h-4"/>}
                    {loading ? "AI 地图探测中..." : "启动雷达探测"}
                  </button>
                  {loading && (
                    <button
                      type="button"
                      onClick={() => {
                        requestAbortSearch();
                        addToast("已请求停止（当前轮询结束后停止）", "info");
                      }}
                      className="w-full py-2.5 bg-white border-2 border-red-100 text-red-600 rounded-2xl font-black flex justify-center items-center gap-2 hover:bg-red-50 transition-all active:scale-95 uppercase tracking-widest"
                    >
                      <X className="w-4 h-4"/>
                      停止搜索
                    </button>
                  )}
                  {searchStatus && <div className="p-2 bg-blue-50 rounded-lg text-blue-600 text-[9px] font-black animate-pulse flex items-center gap-2 italic"><Sparkles className="w-3 h-3"/> {searchStatus}</div>}
              </form>

              {activeTab === 'library' && (
              <div className="space-y-2 mt-2">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">商机评级面板</p>
                  {['全部', 'S', 'A', 'B', 'C'].map(cat => (
                    <button key={cat} onClick={() => setCurrentFilter(cat)} className={`w-full text-left px-4 py-3 rounded-2xl text-[10px] font-black transition-all flex justify-between items-center group ${currentFilter === cat ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-slate-50 text-slate-500 hover:bg-slate-100'}`}>
                        <div className="flex items-center gap-2">
                            <Tag className={`w-3.5 h-3.5 ${currentFilter === cat ? 'text-blue-200' : 'text-slate-300'}`}/>
                            {cat} 级商机
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-[8px] ${currentFilter === cat ? 'bg-blue-500 text-white' : 'bg-slate-200 text-slate-400'}`}>{leads.filter(l => cat === '全部' || l.grade === cat).length}</span>
                    </button>
                  ))}
              </div>
              )}
          </aside>

          <section className="flex-1 flex flex-col overflow-hidden bg-white">
              <div className="h-12 border-b px-5 flex items-center justify-between shrink-0 bg-white/80 backdrop-blur-md">
                  <div className="flex items-center gap-5">
                    <div className="flex items-center gap-1 bg-slate-50 p-1 rounded-2xl border border-slate-100">
                      <button
                        onClick={() => { setActiveTab('radar'); setSelectedIds(new Set()); setSelectedLead(null); }}
                        className={`px-3 py-1.5 rounded-xl text-[10px] font-black transition-all ${activeTab === 'radar' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                      >
                        雷达结果 <span className="text-[8px] opacity-50 ml-1">{radarLeads.length}</span>
                      </button>
                      <button
                        onClick={() => { setActiveTab('library'); setSelectedIds(new Set()); setSelectedLead(null); }}
                        className={`px-3 py-1.5 rounded-xl text-[10px] font-black transition-all ${activeTab === 'library' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                      >
                        客户库 <span className="text-[8px] opacity-50 ml-1">{leads.length}</span>
                      </button>
                    </div>
                    <div className="flex items-center gap-3">
                      <button onClick={handleSelectAll} className={`p-2 rounded-xl transition-all ${selectedIds.size === displayedLeads.length && displayedLeads.length > 0 ? 'text-blue-600 bg-blue-50 border-blue-100 border' : 'text-slate-300 bg-slate-50 border border-transparent'}`}>
                        {selectedIds.size === displayedLeads.length && displayedLeads.length > 0 ? <CheckSquare className="w-5 h-5"/> : <Square className="w-5 h-5"/>}
                      </button>
                      <div className="flex flex-col leading-none">
                        <span className="font-black text-[11px]">已选择 {selectedIds.size} 项</span>
                        <span className="text-[8px] text-slate-400 font-bold uppercase mt-1">批量操作区</span>
                      </div>
                    </div>
                    {selectedIds.size > 0 && (
                      <div className="flex items-center gap-2 animate-fadeIn">
                        <button onClick={handleBatchEnrich} className="px-3 py-1.5 bg-yellow-500 text-white rounded-xl text-[10px] font-black hover:bg-yellow-600 shadow-lg shadow-yellow-100 flex items-center gap-1.5 transition-all active:scale-95"><Zap className="w-3.5 h-3.5"/> 批量 AI 深度探测</button>
                        <button onClick={() => setSelectedIds(new Set())} className="px-3 py-1.5 bg-white border-2 border-slate-100 text-slate-400 rounded-xl text-[10px] font-black hover:bg-slate-50 transition-all">取消选择</button>
                      </div>
                    )}
                    {selectedIds.size === 0 && displayedLeads.length > 0 && (
                      <div className="flex items-center gap-2 animate-fadeIn">
                        <button onClick={handleEnrichAllVisible} className="px-3 py-1.5 bg-slate-900 text-white rounded-xl text-[10px] font-black hover:bg-black shadow-lg shadow-slate-200 flex items-center gap-1.5 transition-all active:scale-95" title="对当前列表全部执行深度探测">
                          <Zap className="w-3.5 h-3.5"/> 一键深度探测（本页）
                        </button>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {activeTab === 'radar' && (
                      <button onClick={handleImportToLibrary} className="px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 flex items-center gap-2 font-black transition-all active:scale-95 shadow-sm">
                        <Database className="w-4 h-4"/> {selectedIds.size > 0 ? '导入所选' : '一键导入客户库'}
                      </button>
                    )}
                    <button onClick={handleExport} className="px-4 py-2 bg-white border-2 border-slate-100 text-slate-700 rounded-xl hover:bg-slate-50 flex items-center gap-2 font-black transition-all active:scale-95 shadow-sm"><FileText className="w-4 h-4 text-blue-500"/> {selectedIds.size > 0 ? '导出所选' : '导出全部'}</button>
                    <button onClick={handleDeleteSelected} disabled={selectedIds.size===0} className={`px-4 py-2 rounded-xl font-black transition-all active:scale-95 shadow-sm flex items-center gap-2 ${selectedIds.size===0?'bg-slate-100 text-slate-300':'bg-red-50 text-red-600 border-2 border-red-50 hover:bg-red-100'}`}>
                      <Trash2 className="w-4 h-4"/> 删除
                    </button>
                    {activeTab === 'library' && (
                      <button onClick={() => {if(confirm('确定清空客户库全部数据吗？此操作不可撤销。')) setLeads([]);}} className="px-4 py-2 bg-white border-2 border-slate-100 text-slate-400 rounded-xl hover:bg-slate-50 font-black transition-all active:scale-95 shadow-sm" title="清空客户库">
                        <X className="w-4 h-4"/>
                      </button>
                    )}
                  </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-4 content-start custom-scrollbar bg-slate-50/30">
                  {displayedLeads.map(lead => (
                    <div key={lead.id} className={`bg-white border-2 rounded-3xl p-4 flex flex-col gap-3 hover:shadow-2xl hover:-translate-y-1 transition-all group relative ${selectedIds.has(lead.id) ? 'border-blue-500 bg-blue-50/10 shadow-blue-50' : 'border-slate-100'}`}>
                        <div className="absolute top-4 left-4 z-10">
                           <button onClick={() => toggleSelect(lead.id)} className={`w-6 h-6 rounded-lg bg-white shadow-md border-2 transition-all flex items-center justify-center ${selectedIds.has(lead.id) ? 'border-blue-500 text-blue-600' : 'border-slate-100 text-transparent hover:border-blue-200'}`}>
                             <CheckSquare className="w-4 h-4"/>
                           </button>
                        </div>
                        
                        <div className="flex justify-between items-start gap-2 pl-8">
                          <h3 className="font-black text-slate-900 line-clamp-1 flex-1 text-[12px] leading-tight group-hover:text-blue-600 transition-colors" title={lead.name}>{lead.name}</h3>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {lead.leadType && lead.leadType !== '未知' && (
                              <span className="px-2 py-0.5 rounded-lg text-[9px] font-black bg-slate-900 text-white shadow-sm">{lead.leadType}</span>
                            )}
                            <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black text-white shadow-sm ${lead.grade === 'S' ? 'bg-purple-600' : lead.grade ? 'bg-blue-600' : 'bg-slate-200 text-slate-400'}`}>{lead.grade || 'NEW'}</span>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-1.5 px-1 py-1 bg-slate-50 rounded-xl">
                            <MapPin className="w-3 h-3 text-slate-400 shrink-0"/>
                            <p className="text-[9px] text-slate-400 line-clamp-1 italic font-bold">{lead.address}</p>
                        </div>
                        
                        <div className="flex flex-col gap-2 py-2 text-[10px] border-y border-slate-50 px-1">
                          {(() => {
                            const phone = (lead.phone && lead.evidence?.phone?.sourceUrl) ? lead.phone : '';
                            const email = (lead.email && lead.evidence?.email?.sourceUrl) ? lead.email : '';
                            return (
                              <>
                                <div className="flex items-center justify-between gap-2">
                                  <span className="text-slate-400 font-bold uppercase text-[8px]">电话</span>
                                  <div className="flex items-center gap-2">
                                    <span className={`font-black ${phone ? 'text-slate-700' : 'text-slate-300 italic'}`}>{phone || '无证据不展示'}</span>
                                    <button
                                      onClick={() => phone && copyToClipboard(phone, '电话')}
                                      disabled={!phone}
                                      className={`p-1.5 rounded-lg border transition-all ${phone ? 'bg-slate-50 border-slate-100 hover:bg-slate-100' : 'bg-slate-50 border-slate-50 opacity-40 cursor-not-allowed'}`}
                                      title={phone ? '点击复制电话' : '为保证属实：需证据才展示/可复制'}
                                    >
                                      <Phone className="w-3.5 h-3.5 text-slate-600"/>
                                    </button>
                                  </div>
                                </div>
                                <div className="flex items-center justify-between gap-2">
                                  <span className="text-slate-400 font-bold uppercase text-[8px]">邮箱</span>
                                  <div className="flex items-center gap-2">
                                    <span className={`font-black truncate max-w-[150px] ${email ? 'text-slate-700' : 'text-slate-300 italic'}`}>{email || '无证据不展示'}</span>
                                    <button
                                      onClick={() => email && copyToClipboard(email, '邮箱')}
                                      disabled={!email}
                                      className={`p-1.5 rounded-lg border transition-all ${email ? 'bg-slate-50 border-slate-100 hover:bg-slate-100' : 'bg-slate-50 border-slate-50 opacity-40 cursor-not-allowed'}`}
                                      title={email ? '点击复制邮箱' : '为保证属实：需证据才展示/可复制'}
                                    >
                                      <Mail className="w-3.5 h-3.5 text-slate-600"/>
                                    </button>
                                  </div>
                                </div>
                              </>
                            );
                          })()}
                        </div>
                        
                        <div className="flex gap-2 pt-1 mt-auto">
                           <button onClick={() => handleIndividualEnrich(lead)} className={`flex-1 py-2.5 rounded-2xl text-[10px] font-black transition-all shadow-md flex items-center justify-center gap-1.5 ${lead.enrichmentStatus === 'loading' ? 'bg-blue-100 text-blue-500' : lead.enrichmentStatus === 'completed' ? 'bg-emerald-500 text-white shadow-emerald-100' : lead.enrichmentStatus === 'probed' ? 'bg-slate-900 text-white shadow-slate-200' : 'bg-yellow-500 text-white hover:bg-yellow-600 shadow-yellow-100'}`}>
                             {lead.enrichmentStatus === 'loading' ? <RefreshCw className="w-3.5 h-3.5 animate-spin"/> : lead.enrichmentStatus === 'completed' ? <CheckCircle2 className="w-3.5 h-3.5"/> : lead.enrichmentStatus === 'probed' ? <Globe2 className="w-3.5 h-3.5"/> : <Zap className="w-3.5 h-3.5"/>}
                             {lead.enrichmentStatus === 'loading' ? "分析中" : lead.enrichmentStatus === 'completed' ? "探测完成" : lead.enrichmentStatus === 'probed' ? "已抓取" : "深度探测"}
                           </button>
                           <button onClick={() => setSelectedLead(lead)} className="p-2.5 bg-slate-900 text-white rounded-2xl hover:bg-black active:scale-90 transition-all shadow-lg shadow-slate-200"><Eye className="w-4 h-4"/></button>
                        </div>
                    </div>
                  ))}
                  {displayedLeads.length === 0 && (
                    <div className="col-span-full h-full flex flex-col items-center justify-center opacity-10 py-32 pointer-events-none">
                      <LayoutDashboard className="w-20 h-20 mb-4 animate-pulse"/>
                      <p className="font-black text-xs tracking-widest uppercase">{activeTab === 'radar' ? '雷达结果为空：请先启动左侧扫描' : '客户库为空：请先从雷达导入或继续探测'}...</p>
                    </div>
                  )}
              </div>
          </section>
      </main>

      {showNetworkModal && createPortal(
          <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-md z-[2000] flex items-center justify-center p-4">
              <div className="bg-white rounded-[40px] w-full max-w-xs p-8 shadow-2xl relative animate-fadeIn border border-slate-100">
                  <button onClick={() => setShowNetworkModal(false)} className="absolute top-6 right-6 p-2 hover:bg-slate-100 rounded-full transition-all"><X className="w-4 h-4"/></button>
                  <h3 className="text-sm font-black mb-6 flex items-center gap-3 text-slate-900"><Globe2 className="w-5 h-5 text-blue-600"/> API 配额监控面板</h3>
                  
                  <div className="mb-8 p-6 bg-slate-50 rounded-3xl border border-slate-100 space-y-4 shadow-inner">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">今日请求进度</span>
                      <span className="text-[12px] font-black text-blue-600 italic">{apiStats.successCount} / 2000</span>
                    </div>
                    <div className="h-2.5 bg-slate-200 rounded-full overflow-hidden shadow-inner">
                      <div className="h-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-1000" style={{ width: `${Math.min((apiStats.successCount / 2000) * 100, 100)}%` }}></div>
                    </div>
                    <div className="flex items-center justify-between pt-2">
                      <div className="flex flex-col">
                        <span className="text-[8px] text-slate-400 font-black uppercase">平均每分钟</span>
                        <span className="text-[12px] font-black text-slate-700 italic">{apiStats.rpm} RPM</span>
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="text-[8px] text-slate-400 font-black uppercase">异常熔断数</span>
                        <span className="text-[12px] font-black text-red-500 italic">{apiStats.errorCount} ERR</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-5">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Gemini API Key</label>
                        <input type="password" value={networkConfig.apiKey} onChange={e => setNetworkConfig({...networkConfig, apiKey: e.target.value})} className="w-full px-5 py-3 bg-slate-50 rounded-2xl outline-none focus:ring-2 ring-blue-500/50 text-[11px] font-black transition-all" placeholder="若留空则使用系统内置" />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Gemini 中转 BaseUrl（国内推荐）</label>
                        <input
                          type="text"
                          value={networkConfig.geminiProxyUrl}
                          onChange={e => setNetworkConfig({ ...networkConfig, geminiProxyUrl: e.target.value })}
                          className="w-full px-5 py-3 bg-slate-50 rounded-2xl outline-none focus:ring-2 ring-blue-500/50 text-[11px] font-black transition-all"
                          placeholder="示例：https://llm-api.mmchat.xyz/gemini（留空=直连官方）"
                        />
                        <p className="text-[9px] text-slate-400 font-bold px-1 leading-snug">说明：这里是“官方 Gemini API 的中转地址”，不需要带 <span className="font-black">{'{url}'}</span>。</p>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">网页抓取代理（省API抓邮箱/社媒）</label>
                        <input
                          type="text"
                          value={networkConfig.fetchProxyUrl}
                          onChange={e => setNetworkConfig({ ...networkConfig, fetchProxyUrl: e.target.value })}
                          className="w-full px-5 py-3 bg-slate-50 rounded-2xl outline-none focus:ring-2 ring-blue-500/50 text-[11px] font-black transition-all"
                          placeholder="必须包含 {url}：如 https://xxx/fetch?url={url}"
                        />
                        <p className="text-[9px] text-slate-400 font-bold px-1 leading-snug">说明：用于浏览器跨域抓取官网 HTML（不消耗 Gemini）。</p>
                      </div>
                      <div className="flex gap-3 pt-2 flex-wrap">
                        <button onClick={() => {
                          localStorage.setItem('yl_api_key', networkConfig.apiKey);
                          localStorage.setItem('yl_gemini_proxy', networkConfig.geminiProxyUrl || '');
                          localStorage.setItem('yl_fetch_proxy', networkConfig.fetchProxyUrl || '');
                          // 兼容旧版本配置（老版本只有一个字段）
                          localStorage.setItem('yl_api_proxy', (networkConfig.geminiProxyUrl || networkConfig.fetchProxyUrl || ''));
                          addToast("核心网络配置已更新并持久化", "success");
                        }} className="flex-1 min-w-[120px] py-3.5 bg-blue-600 text-white rounded-2xl text-[11px] font-black shadow-xl shadow-blue-100 active:scale-95 transition-all">保存变更</button>

                        <button onClick={async () => {
                          setIsTestingApi(true);
                          const res = await testApiKey(networkConfig.apiKey, networkConfig.geminiProxyUrl);
                          setIsTestingApi(false);
                          addToast(res.message, res.success ? "success" : "error");
                        }} disabled={isTestingApi} className="px-5 py-3.5 bg-slate-100 text-slate-600 rounded-2xl text-[11px] font-black hover:bg-slate-200 transition-all">
                          {isTestingApi ? "测试中" : "Gemini连接测试"}
                        </button>

                        <button onClick={async () => {
                          setIsTestingFetch(true);
                          const res = await testFetchProxy(networkConfig.fetchProxyUrl);
                          setIsTestingFetch(false);
                          addToast(res.message, res.success ? "success" : "error");
                        }} disabled={isTestingFetch} className="px-5 py-3.5 bg-slate-100 text-slate-600 rounded-2xl text-[11px] font-black hover:bg-slate-200 transition-all">
                          {isTestingFetch ? "测试中" : "抓取代理测试"}
                        </button>
                      </div>
                  </div>
              </div>
          </div>, document.body
      )}

      {showHelpModal && createPortal(
          <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-md z-[2000] flex items-center justify-center p-4">
              <div className="bg-white rounded-[40px] w-full max-w-lg p-10 shadow-2xl relative animate-fadeIn border border-slate-100">
                  <button onClick={() => setShowHelpModal(false)} className="absolute top-8 right-8 p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5"/></button>
                  <h3 className="text-xl font-black mb-8 flex items-center gap-3 text-blue-600 uppercase italic"><BookOpen className="w-7 h-7"/> YL 智能操作手册</h3>
                  <div className="space-y-6 text-[11px] leading-relaxed text-slate-600 max-h-[450px] overflow-y-auto pr-4 custom-scrollbar">
                      <section className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                        <h4 className="font-black text-slate-900 mb-2 flex items-center gap-2 uppercase tracking-widest text-[10px]"><Zap className="w-4 h-4 text-yellow-500"/> 01. 雷达搜索怎么用</h4>
                        <p>输入【关键词 + 地区】，选择扫描规模（10/50/100 或“不限一直搜”），并勾选你想优先锁定的目标类型（批发/供应/采购/零售/连锁）。系统会自动生成全球多语言探测词并开始地图扫描。</p>
                        <p className="mt-2">搜索结果会进入【雷达结果】页；你可以勾选后【导入客户库】长期保存，或直接导出 CSV。</p>
                      </section>
                      <section className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                        <h4 className="font-black text-slate-900 mb-2 flex items-center gap-2 uppercase tracking-widest text-[10px]"><CheckSquare className="w-4 h-4 text-blue-500"/> 02. 一键全选/一键操作</h4>
                        <p>勾选目标后：可【批量 AI 深度探测】、【导入客户库】、【删除】、【导出】。建议每批不超过 20 条，以降低网络波动与失败率。</p>
                      </section>
                      <section className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                        <h4 className="font-black text-slate-900 mb-2 flex items-center gap-2 uppercase tracking-widest text-[10px]"><ShieldCheck className="w-4 h-4 text-emerald-500"/> 03. 信息保真机制（重要）</h4>
                        <p>电话/邮箱/社媒/决策人等字段，只有在“可追溯到网页证据”时才会显示；如果不确定系统会自动留空（宁缺毋滥）。看到【盾牌】图标代表可点击查看对应证据来源。</p>
                      </section>
                      <section className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                        <h4 className="font-black text-slate-900 mb-2 flex items-center gap-2 uppercase tracking-widest text-[10px]"><Globe2 className="w-4 h-4 text-blue-500"/> 04. 中转代理/连接测试</h4>
                        <p>在【配额看板】里可配置 API Key 与中转 URL。支持两种写法：
                          ① 直接填可用的 Gemini BaseUrl（你的中转服务需要转发到官方 Gemini 接口）；
                          ② 使用带 <span className="font-black">&#123;url&#125;</span> 的 CORS 代理（系统会把官方请求 URL 填进去）。
                        </p>
                        <p className="mt-2">常见报错：
                          ① Key 无效/配额不足 → 更换 Key；
                          ② 网络超时/跨域 → 配置中转 URL 并点【连接测试】；
                          ③ 频率过高 → 降低批量数量/稍等重试。
                        </p>
                      </section>
                      <section className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                        <h4 className="font-black text-slate-900 mb-2 flex items-center gap-2 uppercase tracking-widest text-[10px]"><Crown className="w-4 h-4 text-red-500"/> 05. 卡密/代理商说明</h4>
                        <p>仅创始人可进入后台生成卡密：7/30/180/365/永久/代理商。普通用户只需在登录界面输入卡密即可进入系统。</p>
                      </section>
                      <section className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                        <h4 className="font-black text-slate-900 mb-2 flex items-center gap-2 uppercase tracking-widest text-[10px]"><ShieldCheck className="w-4 h-4 text-emerald-500"/> 06. 常见报错排查</h4>
                        <ul className="list-disc pl-5 space-y-1">
                          <li><b>401/403</b>：API Key 错误、未开通 Gemini、或账号权限不足。</li>
                          <li><b>429</b>：触发限流/配额不足；减少批量深度探测数量，或等待配额恢复。</li>
                          <li><b>网络超时</b>：国内网络波动或中转不稳定；换中转/检查代理可用性。</li>
                          <li><b>快速发掘无结果</b>：多为 CORS 或网站屏蔽；请配置支持 <code>{'{url}'}</code> 的抓取代理。</li>
                        </ul>
                      </section>
                      <section className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                        <h4 className="font-black text-slate-900 mb-2 flex items-center gap-2 uppercase tracking-widest text-[10px]"><FileText className="w-4 h-4 text-blue-500"/> 07. 数据管理：雷达→客户库→导出</h4>
                        <p>扫描得到的线索会进入“雷达结果”。可一键勾选后：① 批量深度探测 ② 导入客户库 ③ 导出 CSV（自动排好：公司名/国家/邮箱/电话/官网/评级/备注）。</p>
                      </section>

                  </div>
              </div>
          </div>, document.body
      )}

      {selectedLead && createPortal(
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-lg z-[2000] flex justify-end">
              <div className="bg-white w-full max-w-md h-full shadow-2xl p-8 flex flex-col animate-slideInRight">
                  <div className="flex justify-between items-center mb-8 shrink-0 border-b pb-6 border-slate-100">
                    <div className="flex flex-col">
                        <h2 className="text-lg font-black tracking-tighter text-slate-900 line-clamp-1 italic uppercase">{selectedLead.name}</h2>
                        <span className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-widest">{selectedLead.address}</span>
                    </div>
                    <button onClick={() => setSelectedLead(null)} className="p-3 bg-slate-50 rounded-2xl hover:bg-slate-100 transition-all active:rotate-90"><X className="w-5 h-5 text-slate-500"/></button>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto space-y-8 pr-2 custom-scrollbar">
                      
{selectedLead.googleMapsUri ? (
  <button onClick={() => window.open(selectedLead.googleMapsUri, '_blank')} className="w-full p-4 bg-slate-900 text-white rounded-[30px] flex items-center justify-between group transition-all hover:bg-blue-600 shadow-xl shadow-slate-200">
    <div className="flex items-center gap-3">
        <MapPin className="w-5 h-5"/>
        <div className="text-left">
            <p className="text-[11px] font-black uppercase tracking-widest">查看地图实景</p>
            <p className="text-[8px] opacity-60 font-bold">在 Google Maps 中定位真实物理坐标</p>
        </div>
    </div>
    <ExternalLink className="w-4 h-4 group-hover:translate-x-1 transition-all"/>
  </button>
) : (
  <div className="w-full p-4 bg-slate-100 text-slate-400 rounded-[30px] flex items-center justify-between border border-slate-200">
    <div className="flex items-center gap-3">
        <MapPin className="w-5 h-5"/>
        <div className="text-left">
            <p className="text-[11px] font-black uppercase tracking-widest">地图实景</p>
            <p className="text-[8px] opacity-60 font-bold">未发现可用的地图链接</p>
        </div>
    </div>
    <ExternalLink className="w-4 h-4 opacity-30"/>
  </div>
)}
                      <div className="bg-slate-50 p-5 rounded-[30px] border border-slate-100 shadow-inner">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1 flex items-center gap-2"><ShieldCheck className="w-3 h-3 text-emerald-500"/> 公司背调速览</p>
                        <div className="grid grid-cols-2 gap-3 mt-4">
                          <div className="bg-white rounded-2xl p-4 border border-slate-100">
                            <p className="text-[8px] text-slate-400 font-black uppercase tracking-widest">评分</p>
                            <p className="text-[14px] font-black text-slate-900 mt-1">{typeof selectedLead.rating === 'number' ? selectedLead.rating.toFixed(1) : '—'}</p>
                          </div>
                          <div className="bg-white rounded-2xl p-4 border border-slate-100">
                            <p className="text-[8px] text-slate-400 font-black uppercase tracking-widest">评论数</p>
                            <p className="text-[14px] font-black text-slate-900 mt-1">{typeof selectedLead.userRatingCount === 'number' ? selectedLead.userRatingCount : '—'}</p>
                          </div>
                          <div className="bg-white rounded-2xl p-4 border border-slate-100 col-span-2">
                            <p className="text-[8px] text-slate-400 font-black uppercase tracking-widest">品类</p>
                            <p className="text-[12px] font-black text-slate-900 mt-1 line-clamp-1">{selectedLead.primaryType || '—'}</p>
                          </div>
                          <div className="bg-white rounded-2xl p-4 border border-slate-100">
                            <p className="text-[8px] text-slate-400 font-black uppercase tracking-widest">备注</p>
                            <p className="text-[12px] font-black text-slate-900 mt-1">{selectedLead.leadType || '未知'}</p>
                          </div>
                          <div className="bg-white rounded-2xl p-4 border border-slate-100">
                            <p className="text-[8px] text-slate-400 font-black uppercase tracking-widest">国家</p>
                            <p className="text-[12px] font-black text-slate-900 mt-1">{selectedLead.country || '—'}</p>
                          </div>
                        </div>
                      </div>


                      <div className="space-y-3">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 flex items-center gap-2"><Phone className="w-3 h-3"/> 核心联络情报</p>
                        <div className="grid grid-cols-1 gap-2">
                          <div className="bg-slate-50 p-4 rounded-[25px] flex items-center justify-between border-2 border-transparent hover:border-slate-200 transition-all shadow-sm">
                            <div className="flex items-center gap-3 overflow-hidden">
                              <div className="w-8 h-8 bg-slate-900 rounded-xl flex items-center justify-center text-white"><Globe className="w-4 h-4"/></div>
                              <span className="font-black truncate text-[11px] italic">{(selectedLead.website && selectedLead.evidence?.website?.sourceUrl) ? selectedLead.website : '待深度探测...'}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              {(selectedLead.website && selectedLead.evidence?.website?.sourceUrl) && <button onClick={() => window.open(ensureHttp(selectedLead.website), '_blank')} className="p-2 hover:text-slate-900 transition-colors" title="打开官网"><ExternalLink className="w-4 h-4 text-slate-300"/></button>}
                              {(selectedLead.website && selectedLead.evidence?.website?.sourceUrl) && <button onClick={() => copyToClipboard(selectedLead.website!, '官网')} className="p-2 hover:text-slate-900 transition-colors" title="复制官网"><Copy className="w-4 h-4 text-slate-300"/></button>}
                              {selectedLead.evidence?.website?.sourceUrl && <button onClick={() => window.open(selectedLead.evidence!.website!.sourceUrl, '_blank')} className="p-2 hover:text-blue-600 transition-colors" title="查看核验证据"><ShieldCheck className="w-4 h-4 text-slate-300"/></button>}
                            </div>
                          </div>
                          <div className="bg-slate-50 p-4 rounded-[25px] flex items-center justify-between border-2 border-transparent hover:border-blue-100 transition-all shadow-sm">
                            <div className="flex items-center gap-3 overflow-hidden">
                              <div className="w-8 h-8 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600"><Mail className="w-4 h-4"/></div>
                              <span className="font-black truncate text-[11px] italic">{(selectedLead.email && selectedLead.evidence?.email?.sourceUrl) ? selectedLead.email : '待深度探测...'}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <div className="flex items-center gap-1">
                                {selectedLead.evidence?.email?.sourceUrl && (
                                  <button
                                    onClick={() => window.open(selectedLead.evidence!.email!.sourceUrl, '_blank')}
                                    className="p-2 hover:text-blue-600 transition-colors"
                                    title="查看邮箱证据来源"
                                  >
                                    <ShieldCheck className="w-4 h-4 text-slate-300"/>
                                  </button>
                                )}
                                {(selectedLead.email && selectedLead.evidence?.email?.sourceUrl) && (
                                  <button onClick={() => copyToClipboard(selectedLead.email!, '邮箱')} className="p-2 hover:text-blue-600 transition-colors" title="复制邮箱">
                                    <Copy className="w-4 h-4 text-slate-300"/>
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="bg-slate-50 p-4 rounded-[25px] flex items-center justify-between border-2 border-transparent hover:border-emerald-100 transition-all shadow-sm">
                            <div className="flex items-center gap-3 overflow-hidden">
                              <div className="w-8 h-8 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600"><Phone className="w-4 h-4"/></div>
                              <span className="font-black truncate text-[11px] italic">{(selectedLead.phone && selectedLead.evidence?.phone?.sourceUrl) ? selectedLead.phone : '待深度探测...'}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              {(selectedLead.phone && selectedLead.evidence?.phone?.sourceUrl) && <button onClick={() => copyToClipboard(selectedLead.phone!, '电话')} className="p-2 hover:text-emerald-600 transition-colors" title="复制电话"><Copy className="w-4 h-4 text-slate-300"/></button>}
                              {selectedLead.evidence?.phone?.sourceUrl && <button onClick={() => window.open(selectedLead.evidence!.phone!.sourceUrl, '_blank')} className="p-2 hover:text-emerald-600 transition-colors" title="查看核验证据"><ShieldCheck className="w-4 h-4 text-slate-300"/></button>}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 flex items-center gap-2"><Sparkles className="w-3 h-3"/> AI 深度背景研判 (中文)</p>
                        <div className="bg-blue-50/40 p-5 rounded-[30px] text-[11px] font-bold leading-relaxed text-slate-700 whitespace-pre-line min-h-[140px] border-2 border-blue-100/30 shadow-inner italic">
                          {selectedLead.aiRemarkTranslated || selectedLead.basicIntro || "正在利用 AI 全网搜集该公司的业务流报告..."}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 flex items-center gap-2"><UserCheck className="w-3 h-3"/> 企业决策人矩阵</p>
                        <div className="space-y-2">
                          {selectedLead.enrichmentStatus === 'completed' ? (
                              selectedLead.decisionMakers?.map((dm, i) => (
                                <div key={i} className="flex items-center justify-between bg-slate-50 p-3 rounded-2xl border border-slate-100">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                                    <span className="font-black text-slate-800">{dm.name}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <span className="text-[9px] bg-white text-slate-400 px-2 py-1 rounded-lg border font-black uppercase">{dm.role}</span>
                                    {dm.sourceUrl && (
                                      <button
                                        onClick={() => window.open(dm.sourceUrl!, '_blank')}
                                        className="p-1.5 rounded-lg bg-white border border-slate-100 hover:bg-slate-50 transition-all"
                                        title="查看决策人证据来源"
                                      >
                                        <ShieldCheck className="w-3.5 h-3.5 text-slate-300"/>
                                      </button>
                                    )}
                                  </div>
                                </div>
                              )) || <p className="text-[10px] text-slate-300 px-4 italic">未识别到关键决策人</p>
                          ) : (
                            <p className="text-[10px] text-slate-300 px-4 italic">请先启动深度探测...</p>
                          )}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 flex items-center gap-2"><Share2 className="w-3 h-3"/> 社交媒体全矩阵</p>
                        <div className="grid grid-cols-5 gap-3">
                          {(() => {
                            const socialReady = selectedLead.enrichmentStatus === 'completed' || selectedLead.enrichmentStatus === 'probed';
                            const items: { id: string; label: string; color: string; icon: any; active: boolean; onClick: () => void }[] = [
                              {
                                id: 'website',
                                label: '官网',
                                color: 'bg-slate-900',
                                icon: <Globe size={18}/>,
                                active: socialReady && !!selectedLead.website && !!selectedLead.evidence?.website?.sourceUrl,
                                onClick: () => selectedLead.website && window.open(ensureHttp(selectedLead.website), '_blank')
                              },
                              {
                                id: 'maps',
                                label: '地图',
                                color: 'bg-slate-900',
                                icon: <MapPin size={18}/>,
                                active: !!selectedLead.googleMapsUri,
                                onClick: () => selectedLead.googleMapsUri && window.open(selectedLead.googleMapsUri, '_blank')
                              },
                              {
                                id: 'linkedin',
                                label: '领英',
                                color: 'bg-[#0077B5]',
                                icon: <Linkedin size={18}/>,
                                active: socialReady && !!selectedLead.socials?.linkedin && !!selectedLead.evidence?.socials?.linkedin?.sourceUrl,
                                onClick: () => selectedLead.socials?.linkedin && window.open(ensureHttp(selectedLead.socials.linkedin), '_blank')
                              },
                              {
                                id: 'facebook',
                                label: 'FB',
                                color: 'bg-[#1877F2]',
                                icon: <Facebook size={18}/>,
                                active: socialReady && !!selectedLead.socials?.facebook && !!selectedLead.evidence?.socials?.facebook?.sourceUrl,
                                onClick: () => selectedLead.socials?.facebook && window.open(ensureHttp(selectedLead.socials.facebook), '_blank')
                              },
                              {
                                id: 'instagram',
                                label: 'Ins',
                                color: 'bg-[#E4405F]',
                                icon: <Instagram size={18}/>,
                                active: socialReady && !!selectedLead.socials?.instagram && !!selectedLead.evidence?.socials?.instagram?.sourceUrl,
                                onClick: () => selectedLead.socials?.instagram && window.open(ensureHttp(selectedLead.socials.instagram), '_blank')
                              },
                              {
                                id: 'x',
                                label: 'X',
                                color: 'bg-slate-900',
                                icon: <Twitter size={18}/>,
                                active: socialReady && !!selectedLead.socials?.twitter && !!selectedLead.evidence?.socials?.twitter?.sourceUrl,
                                onClick: () => selectedLead.socials?.twitter && window.open(ensureHttp(selectedLead.socials.twitter), '_blank')
                              },
                              {
                                id: 'youtube',
                                label: 'YT',
                                color: 'bg-red-600',
                                icon: <PlayCircle size={18}/>,
                                active: socialReady && !!selectedLead.socials?.youtube && !!selectedLead.evidence?.socials?.youtube?.sourceUrl,
                                onClick: () => selectedLead.socials?.youtube && window.open(ensureHttp(selectedLead.socials.youtube), '_blank')
                              },
                              {
                                id: 'tiktok',
                                label: 'TK',
                                color: 'bg-black',
                                icon: <Music2 size={18}/>,
                                active: socialReady && !!selectedLead.socials?.tiktok && !!selectedLead.evidence?.socials?.tiktok?.sourceUrl,
                                onClick: () => selectedLead.socials?.tiktok && window.open(ensureHttp(selectedLead.socials.tiktok), '_blank')
                              },
                              {
                                id: 'whatsapp',
                                label: 'WA',
                                color: 'bg-[#25D366]',
                                icon: <MessageCircle size={18}/>,
                                active: socialReady && !!selectedLead.socials?.whatsapp && !!selectedLead.evidence?.socials?.whatsapp?.sourceUrl,
                                onClick: () => {
                                  const link = buildWhatsAppLink(selectedLead.socials?.whatsapp);
                                  if (link) window.open(link, '_blank');
                                  else if (selectedLead.socials?.whatsapp) copyToClipboard(selectedLead.socials.whatsapp, 'WhatsApp');
                                }
                              },
                              {
                                id: 'wechat',
                                label: '微信',
                                color: 'bg-emerald-600',
                                icon: <Send size={18}/>,
                                active: socialReady && !!selectedLead.socials?.wechat && !!selectedLead.evidence?.socials?.wechat?.sourceUrl,
                                onClick: () => selectedLead.socials?.wechat && copyToClipboard(selectedLead.socials.wechat, '微信')
                              },
                            ];

                            return items.map((it) => (
                              <button
                                key={it.id}
                                onClick={() => it.active && it.onClick()}
                                title={it.active ? `打开/复制：${it.label}` : `${it.label}：未发现`}
                                className={`aspect-square rounded-[22px] flex flex-col items-center justify-center gap-1 text-white transition-all shadow-lg ${it.active ? it.color + ' hover:scale-110 active:scale-90' : 'bg-slate-100 text-slate-300 opacity-40 grayscale cursor-not-allowed'}`}
                              >
                                {it.icon}
                                <span className="text-[8px] font-black opacity-80">{it.label}</span>
                              </button>
                            ));
                          })()}
                        </div>
                      </div>

                      {selectedLead.googleMapsUri && (
                        <div className="space-y-3">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 flex items-center gap-2"><MapPin className="w-3 h-3"/> Google 地图实时画面</p>
                          <div className="rounded-[30px] overflow-hidden border border-slate-100 shadow-inner bg-slate-50">
                            <iframe
                              title="Google Maps"
                              className="w-full h-[220px]"
                              loading="lazy"
                              referrerPolicy="no-referrer-when-downgrade"
                              src={`https://www.google.com/maps?q=${encodeURIComponent(`${selectedLead.name} ${selectedLead.address}`)}&output=embed`}
                            />
                          </div>
                        </div>
                      )}
                      
                      {selectedLead.enrichmentStatus !== 'completed' && (
                        <button onClick={() => handleIndividualEnrich(selectedLead)} className="w-full py-4 bg-yellow-500 text-white rounded-[30px] font-black text-[12px] uppercase shadow-xl shadow-yellow-100 hover:bg-yellow-600 transition-all active:scale-95 flex items-center justify-center gap-3 mt-4">
                          <Zap className="w-5 h-5"/> 立即启动全网深度渗透
                        </button>
                      )}
                  </div>
              </div>
          </div>, document.body
      )}

      <div className="fixed bottom-6 right-6 flex flex-col items-end gap-3 z-[500]">
          <button onClick={() => copyToClipboard("Yaozr888888", "创始人微信")} className="bg-slate-900/95 backdrop-blur-md px-6 py-3.5 rounded-[30px] shadow-2xl flex items-center gap-4 hover:-translate-y-2 transition-all group border border-slate-800">
            <div className="p-2 bg-blue-600 rounded-xl group-hover:rotate-12 transition-transform shadow-lg shadow-blue-500/20">
              <MessageCircle className="w-5 h-5 text-white"/>
            </div>
            <div className="text-left shrink-0">
              <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest leading-none mb-1.5 italic">有任何问题请联系创始人</p>
              <p className="text-[12px] font-black italic text-white leading-none tracking-tighter uppercase">Yaozr888888</p>
            </div>
          </button>
      </div>

      {showAdminPanel && createPortal(
          <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-md z-[2000] flex items-center justify-center p-4">
              <div className="bg-white rounded-[50px] w-full max-w-md p-10 shadow-2xl relative flex flex-col max-h-[85vh] animate-fadeIn border-8 border-slate-50">
                  <button onClick={() => setShowAdminPanel(false)} className="absolute top-8 right-8 p-3 hover:bg-slate-100 rounded-full"><X className="w-5 h-5"/></button>
                  <h3 className="text-xl font-black mb-8 flex items-center gap-3 text-red-600 uppercase italic"><Crown className="w-8 h-8"/> 创始人核心分发后台</h3>
                  <div className="grid grid-cols-2 gap-3 mb-8 shrink-0">
                    {["TRL", "MON", "HALF", "YEAR", "PERM", "AGENT"].map(type => (
                      <button key={type} onClick={() => {
                        const salt = Math.random().toString(36).substring(2, 6).toUpperCase();
                        const key = `${type}-${salt}-${Math.random().toString(36).substring(2).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`;
                        const newKeys = [{key, type, time: new Date().toLocaleString()}, ...generatedKeys];
                        setGeneratedKeys(newKeys);
                        localStorage.setItem('yl_admin_keys_v13', JSON.stringify(newKeys));
                        addToast(`新卡密 ${PLAN_LABELS[type]} 已生成`, "success");
                      }} className="py-4 bg-slate-50 border-2 border-slate-100 rounded-3xl font-black text-[10px] uppercase hover:bg-red-50 hover:border-red-100 transition-all text-slate-700 shadow-sm">{PLAN_LABELS[type]}</button>
                    ))}
                  </div>
                  <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar font-mono text-[10px]">
                    <p className="text-[10px] font-black text-slate-400 uppercase mb-2">卡密生成日志 ({generatedKeys.length})</p>
                    {generatedKeys.map((k,i) => (
                      <div key={i} className="p-4 bg-slate-50 border-2 border-slate-50 rounded-2xl flex items-center justify-between group">
                        <div className="flex flex-col">
                            <span className="font-black text-slate-800 text-[11px] italic tracking-tighter">{k.key}</span>
                            <span className="text-slate-400 text-[8px] font-bold mt-1 uppercase">{k.time}</span>
                        </div>
                        <button onClick={() => copyToClipboard(k.key, "卡密")} className="p-2 bg-white rounded-lg shadow-sm group-hover:text-red-600 transition-all"><Copy className="w-4 h-4"/></button>
                      </div>
                    ))}
                  </div>
              </div>
          </div>, document.body
      )}

      {showSettings && createPortal(
          <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-md z-[2000] flex items-center justify-center p-4">
              <div className="bg-white rounded-[40px] w-full max-w-sm p-10 shadow-2xl relative animate-fadeIn border border-slate-100">
                  <button onClick={() => setShowSettings(false)} className="absolute top-8 right-8 p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5"/></button>
                  <h3 className="text-sm font-black mb-8 flex items-center gap-3 text-slate-900 uppercase italic"><Settings className="w-5 h-5 text-blue-600"/> 全球贸易商身份配置</h3>
                  <div className="space-y-6">
                      <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">您的对外昵称</label>
                          <input value={settings.userName} onChange={e => setSettings({...settings, userName: e.target.value})} className="w-full px-5 py-3.5 bg-slate-50 rounded-2xl outline-none font-black text-[11px] border-2 border-transparent focus:border-blue-500/50" />
                      </div>
                      <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">所属公司全称</label>
                          <input value={settings.userCompany} onChange={e => setSettings({...settings, userCompany: e.target.value})} className="w-full px-5 py-3.5 bg-slate-50 rounded-2xl outline-none font-black text-[11px] border-2 border-transparent focus:border-blue-500/50" />
                      </div>
                      <button onClick={() => { 
                          localStorage.setItem('yl_user_name', settings.userName); 
                          localStorage.setItem('yl_user_company', settings.userCompany); 
                          setShowSettings(false); 
                          addToast("档案已保存", "success"); 
                      }} className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black shadow-xl shadow-blue-100 active:scale-95 transition-all text-xs uppercase tracking-widest">保存业务变更</button>
                      <button onClick={() => { 
                          if(confirm('确定要注销登录吗？')) {
                            localStorage.removeItem('yl_license_v13'); 
                            window.location.reload(); 
                          }
                      }} className="w-full py-3 text-slate-300 text-[9px] uppercase font-black hover:text-red-500 transition-colors">退出系统登录</button>
                  </div>
              </div>
          </div>, document.body
      )}
    </div>
  );
};

export default App;
