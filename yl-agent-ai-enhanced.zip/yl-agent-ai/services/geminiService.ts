
import { GoogleGenAI, Type } from "@google/genai";
import { Lead } from "../types";

export const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// 实时统计看板数据
export const apiStats = {
  lastError: null as string | null,
  successCount: 0,
  errorCount: 0,
  sessionStartTime: Date.now(),
  get rpm() {
    const mins = (Date.now() - this.sessionStartTime) / 60000;
    return mins > 0 ? Math.round(this.successCount / mins) : this.successCount;
  }
};

const getApiConfig = () => {
  return {
    key: localStorage.getItem('yl_api_key') || process.env.API_KEY || "",
    proxy: localStorage.getItem('yl_api_proxy') || ""
  };
};

/**
 * 运行时开关（用于“一直搜/停止搜索”等交互）
 */
export const runtimeFlags = {
  abortSearch: false,
};

export const requestAbortSearch = () => {
  runtimeFlags.abortSearch = true;
};

const clearAbortSearch = () => {
  runtimeFlags.abortSearch = false;
};

/**
 * 代理/中转支持：
 * - 如果你有自己的反向代理，把 generativelanguage.googleapis.com 转发出来，
 *   这里允许填写“基础地址”（例如 https://proxy.example.com/v1beta）。
 * - 如果你用的是 CORS 代理（把目标 URL 当成参数），可用 {url} 占位：
 *   例如 https://proxy.example.com/fetch?url={url}
 */
const buildProxiedUrl = (proxy: string, targetUrl: string) => {
  if (!proxy) return targetUrl;
  const p = proxy.trim();
  if (!p) return targetUrl;
  if (p.includes('{url}')) return p.replace('{url}', encodeURIComponent(targetUrl));

  // 视为 baseUrl 覆盖（例如 https://proxy.example.com/v1beta）
  // targetUrl 形如 https://generativelanguage.googleapis.com/v1beta/...
  const idx = targetUrl.indexOf('/v1beta');
  if (idx !== -1) {
    const suffix = targetUrl.substring(idx); // /v1beta/...
    return p.replace(/\/+$/, '') + suffix;
  }
  // 兜底：直接拼接
  return p.replace(/\/+$/, '') + '/' + encodeURIComponent(targetUrl);
};

/**
 * 用于“省 API”的网页抓取代理（主要解决浏览器 CORS）：
 * - 仅当 proxyUrl 包含 {url} 时认为它是一个通用抓取代理。
 *   例如: https://your-proxy.com/fetch?url={url}
 * - 否则直接返回 targetUrl。
 */
const buildFetchProxyUrl = (proxy: string, targetUrl: string) => {
  const p = String(proxy || '').trim();
  if (!p) return targetUrl;
  if (!p.includes('{url}')) return targetUrl;
  return p.replace('{url}', encodeURIComponent(targetUrl));
};

const safeTextSnippet = (text: string, needle: string, around = 80) => {
  const lower = text.toLowerCase();
  const n = needle.toLowerCase();
  const idx = lower.indexOf(n);
  if (idx === -1) return '';
  const start = Math.max(0, idx - around);
  const end = Math.min(text.length, idx + n.length + around);
  return text.substring(start, end).replace(/\s+/g, ' ').trim();
};

const extractEmails = (html: string) => {
  const matches = html.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/gi) || [];
  const cleaned = matches
    .map(m => m.trim())
    .filter(m => !/example\.(com|org|net)$/i.test(m))
    .filter(m => !m.toLowerCase().includes('your@email'));
  return Array.from(new Set(cleaned)).slice(0, 3);
};

const extractSocialLinks = (html: string) => {
  const hrefs = Array.from(html.matchAll(/href\s*=\s*"([^"]+)"/gi)).map(m => m[1]);
  const links = hrefs
    .map(h => h.trim())
    .filter(Boolean)
    .map(h => {
      try { return new URL(h, 'https://example.com').toString(); } catch { return h; }
    });

  const pick = (re: RegExp) => links.find(u => re.test(u));
  return {
    linkedin: pick(/linkedin\.com\//i),
    facebook: pick(/facebook\.com\//i),
    instagram: pick(/instagram\.com\//i),
    twitter: pick(/(twitter\.com|x\.com)\//i),
    youtube: pick(/(youtube\.com|youtu\.be)\//i),
    tiktok: pick(/tiktok\.com\//i),
    whatsapp: pick(/(wa\.me|whatsapp\.com)\//i),
    wechat: pick(/(weixin|wechat)/i),
  };
};

const resolveUrl = (base: string, href: string) => {
  try { return new URL(href, base).toString(); } catch { return ''; }
};

async function fetchHtml(url: string): Promise<string> {
  const { proxy } = getApiConfig();
  const target = buildFetchProxyUrl(proxy, url);
  const resp = await fetch(target, { method: 'GET' });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  return await resp.text();
}

/**
 * 当 SDK 在某些网络环境不可用时，使用 REST 方式调用（仍然是官方 Gemini API，只是走中转）。
 * 说明：这里只覆盖本项目用到的字段（contents/tools/responseMimeType/responseSchema/maxOutputTokens）。
 */
async function generateContentRest(params: { apiKey: string; proxy?: string; model: string; contents: any; config?: any }) {
  const { apiKey, proxy, model, contents, config } = params;
  const url = buildProxiedUrl(proxy || '', `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`);

  // 将 SDK 的 config 结构映射到 REST 的 request body
  const body: any = {
    contents: typeof contents === 'string' ? [{ parts: [{ text: contents }] }] : contents,
  };

  if (config?.tools) body.tools = config.tools;

  const generationConfig: any = {};
  if (config?.maxOutputTokens) generationConfig.maxOutputTokens = config.maxOutputTokens;
  if (config?.temperature !== undefined) generationConfig.temperature = config.temperature;

  // JSON 模式字段：REST 示例里用 response_mime_type/response_schema
  if (config?.responseMimeType) generationConfig.response_mime_type = config.responseMimeType;
  if (config?.responseSchema) generationConfig.response_schema = config.responseSchema;
  if (Object.keys(generationConfig).length) body.generationConfig = generationConfig;

  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (!resp.ok) {
    const t = await resp.text().catch(() => '');
    throw new Error(`HTTP ${resp.status}: ${t || resp.statusText}`);
  }
  const json = await resp.json();
  // 模拟 SDK 的常用字段：text + candidates
  const text = json?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).filter(Boolean).join('') || '';
  return { ...json, text, candidates: json.candidates };
}

/**
 * 核心去重算法：名称归一化 + 地址指纹
 */
const normalizeBusinessName = (name: string): string => {
  if (!name) return "";
  return name.toLowerCase()
    .replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "")
    .replace(/\s+/g, "")
    .replace(/(inc|ltd|limited|corp|company|co|llc|gmbh|sa|pvt|pty|intl|group)$/g, "");
};

const isLeadDuplicate = (newLead: Partial<Lead>, existingLeads: Lead[]): boolean => {
  const normName = normalizeBusinessName(newLead.name || "");
  const normAddr = (newLead.address || "").toLowerCase().replace(/\s+/g, "").substring(0, 15);
  return existingLeads.some(l => {
    if (newLead.id && l.id === newLead.id) return true;
    const exName = normalizeBusinessName(l.name);
    const exAddr = l.address.toLowerCase().replace(/\s+/g, "").substring(0, 15);
    if (normName === exName && normAddr === exAddr) return true;
    if (newLead.website && l.website && newLead.website.replace(/https?:\/\//, "") === l.website.replace(/https?:\/\//, "")) return true;
    return false;
  });
};

export const testApiKey = async (customKey?: string, customProxy?: string): Promise<{ success: boolean; message: string }> => {
  const { key, proxy } = getApiConfig();
  const targetKey = customKey || key;
  const targetProxy = (customProxy !== undefined ? customProxy : proxy) || '';

  if (!targetKey) return { success: false, message: "请先输入 API 密钥。" };
  try {
    // 优先尝试 REST（更能反映“中转”是否可用）；失败再回退 SDK。
    let response: any;
    try {
      if (!targetProxy) throw new Error('NO_PROXY');
      response = await generateContentRest({ apiKey: targetKey, proxy: targetProxy, model: 'gemini-3-flash-preview', contents: '测试连接', config: { maxOutputTokens: 5 } });
    } catch (e) {
      const ai = new GoogleGenAI({ apiKey: targetKey });
      response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: '测试连接',
        config: { maxOutputTokens: 5 }
      });
    }
    return response.text ? { success: true, message: "API 状态：绿色通行！" } : { success: false, message: "API 响应异常。" };
  } catch (e: any) {
    return { success: false, message: "连接失败: " + e.message };
  }
};

async function callAiWithRetry(model: string, contents: any, config: any = {}, retries = 2): Promise<any> {
  const { key, proxy } = getApiConfig();
  if (!key) throw new Error("请先打开【配额看板】配置 Gemini API Key（或使用系统内置 Key）。");
  for (let i = 0; i <= retries; i++) {
    try {
      // 如果用户配置了中转/代理，优先走 REST（可绕开部分网络限制）。
      const response = proxy
        ? await generateContentRest({ apiKey: key, proxy, model, contents, config })
        : await (async () => {
            const ai = new GoogleGenAI({ apiKey: key });
            return await ai.models.generateContent({ model, contents, config });
          })();
      apiStats.successCount++;
      apiStats.lastError = null;
      return response;
    } catch (error: any) {
      apiStats.errorCount++;
      apiStats.lastError = error?.message || "网络波动";
      if (i < retries && (error?.status === "RESOURCE_EXHAUSTED" || error?.message?.includes("429"))) {
        await sleep(3000 * (i + 1));
        continue;
      }
      throw error;
    }
  }
}

const generateDeterministicId = (name: string, address: string): string => {
  const str = `${name}-${address}`.toLowerCase().replace(/[^a-z0-9]/g, '');
  let hash = 0;
  for (let i = 0; i < str.length; i++) hash = ((hash << 5) - hash) + str.charCodeAt(i) | 0;
  return `gen-${Math.abs(hash)}`;
};

const inferLeadType = (q: string, primaryType?: string): Lead['leadType'] => {
  const s = `${q} ${primaryType || ''}`.toLowerCase();
  if (/(wholesale|distributor|批发|分销)/i.test(s)) return '批发商';
  if (/(manufacturer|factory|supplier|工厂|制造|供应商)/i.test(s)) return '供应商';
  if (/(importer|buyer|purchasing|采购|进口)/i.test(s)) return '采购商';
  if (/(chain|locations|franchise|连锁)/i.test(s)) return '连锁店';
  if (/(store|shop|retail|boutique|零售|门店)/i.test(s)) return '零售店';
  if (primaryType && /(restaurant|cafe|store|shop)/i.test(primaryType)) return '零售店';
  return '未知';
};

export const searchBusinessesOnMap = async (
  query: string,
  location: string,
  limit: number,
  onStatusUpdate?: (status: string) => void,
  targets?: string[]
): Promise<{leads: Lead[], usedQueries: string[]}> => {
  clearAbortSearch();
  const existingJson = localStorage.getItem('yl_leads_v13');
  let currentDb: Lead[] = existingJson ? JSON.parse(existingJson) : [];
  
  onStatusUpdate?.('AI 正在制定全球多语言探测方案（批发/供应/采购/零售/门店全覆盖）...');
  const targetHint = (targets && targets.length)
    ? `\n\n用户选择的重点目标：${targets.join('、')}（请优先覆盖这些目标）。`
    : '';
  const fissionPrompt = `你是一个全球外贸获客雷达。目标：尽可能找到“真实存在的公司/门店”。\n\n给定行业关键词："${query}"；目标地区："${location}"。${targetHint}\n\n请生成 30 条“可用于地图/搜索引擎”的搜索词（混合英文 + 当地语言 + 行业同义词），并尽量覆盖以下目标：\n- 批发商/分销商 (wholesale / distributor)\n- 供应商/工厂 (manufacturer / factory / supplier)\n- 采购商/进口商 (importer / buyer / purchasing)\n- 零售店/店主 (store / shop / retail)\n- 连锁品牌/门店 (chain store / locations)\n\n要求：\n1) 每条搜索词尽量具体（可带 city/area）。\n2) 不要输出解释，只返回 JSON 字符串数组。`;
  
  let strategies = [query];
  try {
    const stratRes = await callAiWithRetry("gemini-3-flash-preview", fissionPrompt, { 
      responseMimeType: "application/json", 
      responseSchema: { type: Type.ARRAY, items: { type: Type.STRING } } 
    });
    strategies = JSON.parse(stratRes.text || "[]");
  } catch (e) {}

  // 去重 + 清理
  strategies = Array.from(new Set(strategies.map(s => String(s || '').trim()).filter(Boolean)));
  if (!strategies.includes(query)) strategies.unshift(query);

  // “一直搜”：当用户选择 0 时，策略不够就继续裂变补充
  const ensureMoreStrategies = async () => {
    if (runtimeFlags.abortSearch) return;
    if (strategies.length >= 80) return;
    const morePrompt = `继续为 "${query}" 在 "${location}" 生成更多 30 条不同的搜索词（不要重复已有的：${strategies.slice(0, 40).join(' | ')}）。只返回 JSON 字符串数组。`;
    try {
      const moreRes = await callAiWithRetry("gemini-3-flash-preview", morePrompt, {
        responseMimeType: "application/json",
        responseSchema: { type: Type.ARRAY, items: { type: Type.STRING } }
      });
      const more = JSON.parse(moreRes.text || '[]');
      const merged = Array.from(new Set([...strategies, ...more.map((s: any) => String(s || '').trim())].filter(Boolean)));
      strategies = merged;
    } catch (e) {}
  };

  const results: Lead[] = [];
  for (let idx = 0; idx < strategies.length; idx++) {
    const q = strategies[idx];
    if (runtimeFlags.abortSearch) throw new Error('已停止搜索');
    if (limit > 0 && results.length >= limit) break;
    if (limit === 0 && idx > 0 && idx % 25 === 0) await ensureMoreStrategies();
    try {
      onStatusUpdate?.(`正在调用地图引擎扫描: ${q}...`);
      // 修正：Google Maps 工具必须使用 gemini-2.5 系列模型
      const response = await callAiWithRetry("gemini-2.5-flash", `Find businesses for "${q}" in "${location}". Prefer real companies/stores with verifiable contact channels (website/phone).`, { 
        tools: [{ googleMaps: {} }, { googleSearch: {} }]
      });
      
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      chunks.forEach((chunk: any) => {
        // 1) 地图线索（实体门店/工厂/办公室）
        if (chunk.maps) {
          const m = chunk.maps;
          const id = m.placeId || generateDeterministicId(m.title, m.address || location);
          const primaryType = m.primaryType || (Array.isArray(m.types) ? m.types.join(',') : (m.category || ''));
          const potentialLead: Partial<Lead> = { id, name: m.title, address: m.address || location, website: m.websiteUri };

          if (!isLeadDuplicate(potentialLead, [...results, ...currentDb])) {
            results.push({
              id,
              name: m.title,
              address: m.address || location,
              country: location,
              website: m.websiteUri,
              googleMapsUri: m.uri,
              phone: m.phoneNumber || undefined,
              rating: typeof m.rating === 'number' ? m.rating : undefined,
              userRatingCount: typeof m.userRatingCount === 'number' ? m.userRatingCount : undefined,
              primaryType: primaryType ? String(primaryType) : undefined,
              basicIntro: `雷达探测到: ${q}`,
              leadType: inferLeadType(q, String(primaryType || '')),
              enrichmentStatus: 'idle',
              emailStatus: 'new',
              socials: {},
              evidence: {
                website: m.websiteUri ? { sourceUrl: m.uri, evidence: `Google Maps: ${String(m.websiteUri)}` } : undefined,
                phone: m.phoneNumber ? { sourceUrl: m.uri, evidence: `Google Maps: ${String(m.phoneNumber)}` } : undefined,
                socials: {},
              }
            });
          }
        }

        // 2) 搜索线索（公司官网/目录页/连锁门店页等）：用于扩大覆盖面
        if (chunk.web && chunk.web.uri && chunk.web.title) {
          const uri = String(chunk.web.uri || '').trim();
          const title = String(chunk.web.title || '').trim();
          const bad = /(wikipedia\.org|wikidata\.org|google\.com\/maps|support\.google\.com|accounts\.google\.com|policies\.google\.com)/i;
          if (uri.startsWith('http') && title && !bad.test(uri)) {
            const id = generateDeterministicId(title, uri);
            const potentialLead: Partial<Lead> = { id, name: title, address: location, website: uri };
            if (!isLeadDuplicate(potentialLead, [...results, ...currentDb])) {
              results.push({
                id,
                name: title,
                address: location,
                country: location,
                website: uri,
                googleMapsUri: undefined,
                basicIntro: `搜索索引到: ${q}`,
                leadType: inferLeadType(q, ''),
                enrichmentStatus: 'idle',
                emailStatus: 'new',
                socials: {},
                evidence: {
                  website: { sourceUrl: uri, evidence: `Google Search: ${title} -> ${uri}` },
                  socials: {},
                }
              });
            }
          }
        }
      });
      if (limit > 0 && results.length >= limit) break;
    } catch (e) { console.error(e); }
  }
  return { leads: results, usedQueries: strategies };
};

export const enrichLeadWithSearch = async (lead: Lead): Promise<Partial<Lead>> => {
  const prompt = `你是“外贸客户深度发掘器”，但必须“信息保真”。\n\n目标公司："${lead.name}"，地址/地区："${lead.address}"。\n\n任务：只用【Google Search 工具】找“可核验”的信息，并输出 JSON。\n\n保真规则（非常重要）：\n- 任何 Email/电话/社媒链接/决策人信息，必须给出 sourceUrl + evidence（evidence 里必须包含该 Email/电话/链接/姓名）；否则不要输出（填空字符串）。\n- 允许输出 AI 研判（grade/aiRemark），但它是“推断”，不要伪装成事实。\n\n需要字段：\n1) website/email/phone（每个都要证据）\n2) socials: linkedin/facebook/instagram/twitter/youtube/tiktok/whatsapp/wechat（每个都要证据）\n3) decisionMakers: 最多 2 个（name/role/sourceUrl/evidence；必须证据）\n4) leadType: 供应商/批发商/采购商/零售店/连锁店/店主/老板/服务商/未知（这是分类，可推断）\n5) grade: S/A/B/C（推断）\n6) aiRemark: 中文，简洁（推断，说明理由，如“有官网/多门店/联系方式齐全/评论多”等）\n\n请只返回 JSON。`;

  const response = await callAiWithRetry("gemini-3-flash-preview", prompt, {
    tools: [{ googleSearch: {} }],
    responseMimeType: "application/json",
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        leadType: { type: Type.STRING },
        grade: { type: Type.STRING },
        aiRemark: { type: Type.STRING },
        website: {
          type: Type.OBJECT,
          properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } }
        },
        email: {
          type: Type.OBJECT,
          properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } }
        },
        phone: {
          type: Type.OBJECT,
          properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } }
        },
        socials: {
          type: Type.OBJECT,
          properties: {
            linkedin: { type: Type.OBJECT, properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } },
            facebook: { type: Type.OBJECT, properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } },
            instagram: { type: Type.OBJECT, properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } },
            twitter: { type: Type.OBJECT, properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } },
            youtube: { type: Type.OBJECT, properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } },
            tiktok: { type: Type.OBJECT, properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } },
            whatsapp: { type: Type.OBJECT, properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } },
            wechat: { type: Type.OBJECT, properties: { value: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } },
          }
        },
        decisionMakers: {
          type: Type.ARRAY,
          items: { type: Type.OBJECT, properties: { name: { type: Type.STRING }, role: { type: Type.STRING }, sourceUrl: { type: Type.STRING }, evidence: { type: Type.STRING } } }
        },
      }
    }
  });

  const allowedUrls = new Set<string>();
  (response.candidates?.[0]?.groundingMetadata?.groundingChunks || []).forEach((c: any) => {
    const u = c?.web?.uri || c?.web?.url || c?.web?.source || c?.maps?.uri;
    if (u) allowedUrls.add(String(u));
  });

  const data = JSON.parse(response.text || '{}');

  const cleanEvidence = (obj: any) => {
    const value = String(obj?.value || '').trim();
    const sourceUrl = String(obj?.sourceUrl || '').trim();
    const evidence = String(obj?.evidence || '').trim();
    if (!value || !sourceUrl || !evidence) return null;
    if (allowedUrls.size > 0 && !allowedUrls.has(sourceUrl)) return null;
    // 证据里必须包含 value（用于“筛选掉幻觉”）
    if (!evidence.toLowerCase().includes(value.toLowerCase())) return null;
    return { value, sourceUrl, evidence };
  };

  const out: Partial<Lead> = {
    leadType: (['供应商','批发商','采购商','零售店','连锁店','店主/老板','服务商','未知'] as const).includes(data.leadType) ? data.leadType : '未知',
    grade: (['S','A','B','C'] as const).includes(data.grade) ? data.grade : 'B',
    aiRemark: String(data.aiRemark || '').trim(),
    aiRemarkTranslated: String(data.aiRemark || '').trim(),
    socials: { ...lead.socials },
    evidence: { socials: {} },
    decisionMakers: [],
    enrichmentStatus: 'completed',
  };

  // website/email/phone
  const w = cleanEvidence(data.website);
  if (w) {
    out.website = w.value;
    out.evidence = { ...(out.evidence || {}), website: { sourceUrl: w.sourceUrl, evidence: w.evidence }, socials: (out.evidence?.socials || {}) };
  }
  const e = cleanEvidence(data.email);
  if (e && /\S+@\S+\.[A-Za-z]{2,}/.test(e.value)) {
    out.email = e.value;
    out.evidence = { ...(out.evidence || {}), email: { sourceUrl: e.sourceUrl, evidence: e.evidence }, socials: (out.evidence?.socials || {}) };
  }
  const p = cleanEvidence(data.phone);
  if (p) {
    out.phone = p.value;
    out.evidence = { ...(out.evidence || {}), phone: { sourceUrl: p.sourceUrl, evidence: p.evidence }, socials: (out.evidence?.socials || {}) };
  }

  // socials
  const socials: any = data.socials || {};
  const platformRules: Record<string, RegExp> = {
    linkedin: /linkedin\.com/i,
    facebook: /facebook\.com/i,
    instagram: /instagram\.com/i,
    twitter: /(twitter\.com|x\.com)/i,
    youtube: /(youtube\.com|youtu\.be)/i,
    tiktok: /tiktok\.com/i,
    whatsapp: /(wa\.me|whatsapp\.com)/i,
    wechat: /(weixin|wechat)/i,
  };

  const isPhoneLike = (val: string) => /^\+?[0-9][0-9\s().-]{5,}$/.test(val.replace(/\s+/g, ' ').trim());
  const isWeChatIdLike = (val: string) => /^[a-zA-Z][-_a-zA-Z0-9]{4,29}$/.test(val.trim());

  const socialsOut: any = { ...lead.socials };
  const socialsEvidence: Record<string, any> = { ...(out.evidence?.socials || {}) };

  Object.keys(platformRules).forEach((k) => {
    const v = cleanEvidence(socials[k]);
    if (!v) return;
    const value = String(v.value || '').trim();
    if (!value) return;

    // WhatsApp：允许链接或手机号（证据仍需包含）
    if (k === 'whatsapp') {
      if (platformRules.whatsapp.test(value) || isPhoneLike(value)) {
        socialsOut[k] = value;
        socialsEvidence[k] = { sourceUrl: v.sourceUrl, evidence: v.evidence };
      }
      return;
    }

    // 微信：可能是链接、也可能只是 ID（允许 ID，但必须有证据）
    if (k === 'wechat') {
      const cleaned = value.replace(/^wechat\s*[:：]\s*/i, '').replace(/^weixin\s*[:：]\s*/i, '').trim();
      if (platformRules.wechat.test(cleaned) || isWeChatIdLike(cleaned)) {
        socialsOut[k] = cleaned;
        socialsEvidence[k] = { sourceUrl: v.sourceUrl, evidence: v.evidence };
      }
      return;
    }

    // 其他平台：必须是对应域名链接
    if (!platformRules[k].test(value)) return;
    socialsOut[k] = value;
    socialsEvidence[k] = { sourceUrl: v.sourceUrl, evidence: v.evidence };
  });

  out.socials = socialsOut;
  out.evidence = { ...(out.evidence || {}), socials: socialsEvidence };

  // decision makers（严格保真）
  const dms: any[] = Array.isArray(data.decisionMakers) ? data.decisionMakers : [];
  const cleanedDms = dms
    .map((dm) => ({
      name: String(dm?.name || '').trim(),
      role: String(dm?.role || '').trim(),
      sourceUrl: String(dm?.sourceUrl || '').trim(),
      evidence: String(dm?.evidence || '').trim(),
    }))
    .filter((dm) => dm.name && dm.role && dm.sourceUrl && dm.evidence)
    .filter((dm) => (allowedUrls.size === 0 ? true : allowedUrls.has(dm.sourceUrl)))
    .filter((dm) => dm.evidence.toLowerCase().includes(dm.name.toLowerCase()))
    .slice(0, 2);
  out.decisionMakers = cleanedDms;

  return out;
};

const ensureHttp = (url?: string) => {
  if (!url) return '';
  const u = String(url).trim();
  if (!u) return '';
  if (u.startsWith('http://') || u.startsWith('https://')) return u;
  return `https://${u.replace(/^\/\//, '')}`;
};

/**
 * 省 API 快速发掘：
 * - 不调用 Gemini，只抓取官网 HTML，通过正则提取 Email 与社媒链接。
 * - 证据：sourceUrl 为抓取页面，evidence 为包含目标字段的文本片段。
 *
 * 注意：浏览器环境可能遇到 CORS，因此建议在“中转代理 URL”中填入支持 {url} 的抓取代理。
 */
export const quickEnrichLeadFromWebsite = async (lead: Lead): Promise<Partial<Lead>> => {
  const { proxy } = getApiConfig();
  const website = ensureHttp(lead.website);
  if (!website) return {};

  const fetchText = async (url: string) => {
    const controller = new AbortController();
    const t = setTimeout(() => controller.abort(), 12000);
    try {
      const finalUrl = buildFetchProxyUrl(proxy, url);
      const resp = await fetch(finalUrl, {
        method: 'GET',
        headers: { 'Accept': 'text/html,application/xhtml+xml' },
        signal: controller.signal,
      });
      const txt = await resp.text();
      return txt;
    } finally {
      clearTimeout(t);
    }
  };

  try {
    const homeHtml = await fetchText(website);
    const homeEmails = extractEmails(homeHtml);
    const socialsFound = extractSocialLinks(homeHtml);

    // 试探联系页（最多再抓 2 个）
    const contactCandidates = Array.from(homeHtml.matchAll(/href\s*=\s*"([^"]+)"/gi))
      .map(m => m[1])
      .filter(Boolean)
      .filter(h => /(contact|about|impressum|support|privacy|terms|kontakt|contatto|contato|联系我们|联系|关于)/i.test(h))
      .slice(0, 6)
      .map(h => resolveUrl(website, h))
      .filter(Boolean);

    const pagesToFetch = Array.from(new Set([website, ...contactCandidates])).slice(0, 3);

    let bestEmail: { value: string; sourceUrl: string; evidence: string } | null = null;
    const socialsEvidence: Record<string, { sourceUrl: string; evidence: string }> = {};
    const socialsOut: any = { ...(lead.socials || {}) };

    for (const pageUrl of pagesToFetch) {
      let html = homeHtml;
      if (pageUrl !== website) {
        try { html = await fetchText(pageUrl); } catch { continue; }
      }
      const emails = extractEmails(html);
      const pickEmail = emails.find(e => /@(?!example\.)/i.test(e));
      if (!bestEmail && pickEmail) {
        const snippet = safeTextSnippet(html, pickEmail);
        if (snippet) bestEmail = { value: pickEmail, sourceUrl: pageUrl, evidence: snippet };
      }
      const socials = extractSocialLinks(html);
      Object.entries(socials).forEach(([k, v]) => {
        if (!v) return;
        if (socialsOut[k]) return;
        const snippet = safeTextSnippet(html, v);
        if (!snippet) return;
        socialsOut[k] = v;
        socialsEvidence[k] = { sourceUrl: pageUrl, evidence: snippet };
      });
    }

    // home 页面社媒兜底
    Object.entries(socialsFound).forEach(([k, v]) => {
      if (!v) return;
      if (socialsOut[k]) return;
      const snippet = safeTextSnippet(homeHtml, v);
      if (!snippet) return;
      socialsOut[k] = v;
      socialsEvidence[k] = { sourceUrl: website, evidence: snippet };
    });

    const out: Partial<Lead> = {
      socials: socialsOut,
      evidence: {
        ...(lead.evidence || {}),
        socials: { ...(lead.evidence?.socials || {}), ...socialsEvidence },
      }
    };
    if (!lead.email && bestEmail && /\S+@\S+\.[A-Za-z]{2,}/.test(bestEmail.value)) {
      out.email = bestEmail.value;
      out.evidence = { ...(out.evidence || {}), email: { sourceUrl: bestEmail.sourceUrl, evidence: bestEmail.evidence }, socials: (out.evidence?.socials || {}) };
    }
    return out;
  } catch {
    return {};
  }
};
