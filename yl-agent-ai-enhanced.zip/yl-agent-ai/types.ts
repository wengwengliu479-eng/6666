
export type EmailStatus = 'new' | 'generated' | 'sent' | 'opened' | 'replied' | 'converted' | 'bounced';

export interface DecisionMaker {
  name: string;
  role: string;
  /** 必须可追溯来源，否则在 UI 中会被视为“不确定”而隐藏 */
  sourceUrl?: string;
  evidence?: string;
}

export interface EvidenceItem {
  sourceUrl: string;
  evidence: string;
}

export interface Lead {
  id: string;
  name: string;
  address: string;
  country?: string;
  /** 来自地图的基础背调：评分/评论数/品类（可选） */
  rating?: number;
  userRatingCount?: number;
  primaryType?: string;
  /** 线索类型：用于区分批发/零售/连锁等（用于“备注好来”） */
  leadType?: '供应商' | '批发商' | '采购商' | '零售店' | '连锁店' | '店主/老板' | '服务商' | '未知';
  basicIntro?: string; // 基础版获客：简短介绍
  website?: string;
  googleMapsUri?: string;
  email?: string;
  phone?: string;
  socials?: {
    linkedin?: string;
    facebook?: string;
    instagram?: string;
    twitter?: string;
    youtube?: string;
    tiktok?: string;
    whatsapp?: string;
    wechat?: string;
  };
  grade?: 'S' | 'A' | 'B' | 'C'; 
  aiRemark?: string; 
  aiRemarkTranslated?: string;
  businessTags?: string[]; 
  decisionMakers?: DecisionMaker[];
  /** 所有“必须属实”的信息，都要携带证据。否则 UI 会隐藏/置灰。 */
  evidence?: {
    website?: EvidenceItem;
    email?: EvidenceItem;
    phone?: EvidenceItem;
    socials?: Record<string, EvidenceItem>;
  };
  enrichmentStatus: 'idle' | 'loading' | 'probed' | 'completed' | 'failed';
  emailStatus: EmailStatus;
  generatedDraft?: {
      subject: string;
      content: string;
  };
}

export interface SearchParams {
  query: string;
  location: string;
  limit: 10 | 50 | 100 | 0; // 0 代表不设上限
  /** 省 API 模式：尝试从官网页面直接抓取邮箱/社媒（需要在“配额看板”里配置可用的抓取代理 {url}） */
  probeWebsite?: boolean;
  /** 强力增强：补充使用 Google Search（少量调用）挖掘“采购商/进口商/目录类网站”线索 */
  webBoost?: boolean;
  /** 可选：目标类型标签，用于增强搜索覆盖面 */
  targets?: Array<'批发商/分销商' | '供应商/工厂' | '采购商/进口商' | '零售店/店主' | '连锁品牌/门店'>;
}
